// Unit tests for studio-core.js (no browser, no three.js needed)
const assert = require('node:assert/strict');
const S = require('./studio-core.js');

let passed = 0;
function t(name, fn) {
  try { fn(); passed++; console.log('PASS ' + name); }
  catch (e) { console.log('FAIL ' + name + '\n  ' + e.message); process.exitCode = 1; }
}

t('add each primitive shape with defaults', () => {
  let st = S.emptyState();
  for (const shape of ['cube', 'sphere', 'cylinder']) {
    const r = S.addShape(st, shape);
    st = r.state;
    assert.equal(S.getObject(st, r.id).type, shape);
  }
  assert.equal(st.objects.length, 3);
  assert.equal(st.selectedId, st.objects[2].id);
  assert.deepEqual(st.objects[0].scale, [1, 1, 1]);
  assert.match(st.objects[0].color, /^#[0-9a-f]{6}$/);
});

t('unknown shape is rejected', () => {
  assert.throws(() => S.addShape(S.emptyState(), 'pyramid'), /Unknown shape/);
});

t('auto names are numbered per type', () => {
  let st = S.emptyState();
  st = S.addShape(st, 'cube').state;
  st = S.addShape(st, 'cube').state;
  st = S.addShape(st, 'sphere').state;
  assert.deepEqual(st.objects.map(o => o.name), ['Cube 1', 'Cube 2', 'Sphere 1']);
});

t('scene limit is enforced', () => {
  let st = S.emptyState();
  for (let i = 0; i < S.MAX_OBJECTS; i++) st = S.addShape(st, 'cube').state;
  assert.throws(() => S.addShape(st, 'cube'), /Scene limit/);
  assert.throws(() => S.duplicateObject(st, st.objects[0].id), /Scene limit/);
});

t('update validates and clamps values', () => {
  let st = S.addShape(S.emptyState(), 'cube').state;
  const id = st.objects[0].id;
  st = S.updateObject(st, id, { position: [1, 2, 3], scale: [0, 500, 2], color: '#FF0000', roughness: 4, metalness: -1, name: '  Hero  ' });
  const o = S.getObject(st, id);
  assert.deepEqual(o.position, [1, 2, 3]);
  assert.deepEqual(o.scale, [0.01, 100, 2]);
  assert.equal(o.color, '#ff0000');
  assert.equal(o.roughness, 1);
  assert.equal(o.metalness, 0);
  assert.equal(o.name, 'Hero');
});

t('imported GLB keeps original materials until edited', () => {
  let st = S.addObject(S.emptyState(), { type: 'glb', name: 'Car', glbRef: 'g1' }).state;
  const o = st.objects[0];
  assert.equal(o.color, null);
  assert.equal(o.roughness, null);
  assert.equal(o.glbRef, 'g1');
  st = S.updateObject(st, o.id, { color: '#abcdef' });
  assert.equal(S.getObject(st, o.id).color, '#abcdef');
  const d = S.duplicateObject(st, o.id);
  assert.equal(S.getObject(d.state, d.id).glbRef, 'g1');
});

t('update rejects bad input', () => {
  const st = S.addShape(S.emptyState(), 'cube').state;
  const id = st.objects[0].id;
  assert.throws(() => S.updateObject(st, id, { color: 'red' }), /#RRGGBB/);
  assert.throws(() => S.updateObject(st, id, { position: [1, NaN, 3] }), /three numbers/);
  assert.throws(() => S.updateObject(st, id, { scale: [1, 2] }), /three numbers/);
  assert.throws(() => S.updateObject(st, id, { name: '   ' }), /empty/);
  assert.throws(() => S.updateObject(st, id, { roughness: 'high' }), /number/);
  assert.throws(() => S.updateObject(st, 'missing', { name: 'x' }), /not found/);
});

t('update never mutates the previous state', () => {
  const st = S.addShape(S.emptyState(), 'cube').state;
  const before = JSON.stringify(st);
  S.updateObject(st, st.objects[0].id, { color: '#000000' });
  assert.equal(JSON.stringify(st), before);
});

t('duplicate copies properties, offsets and selects the copy', () => {
  let st = S.addShape(S.emptyState(), 'sphere').state;
  const srcId = st.objects[0].id;
  st = S.updateObject(st, srcId, { color: '#123456', metalness: 0.7 });
  const r = S.duplicateObject(st, srcId);
  assert.equal(r.state.objects.length, 2);
  const copy = S.getObject(r.state, r.id);
  assert.equal(copy.type, 'sphere');
  assert.equal(copy.color, '#123456');
  assert.equal(copy.metalness, 0.7);
  assert.equal(copy.name, 'Sphere 1 copy');
  assert.equal(copy.position[0], S.getObject(st, srcId).position[0] + 1);
  assert.equal(r.state.selectedId, r.id);
  // copy is independent
  const r2 = S.updateObject(r.state, r.id, { color: '#ffffff' });
  assert.equal(S.getObject(r2, srcId).color, '#123456');
});

t('delete removes the object and clears selection', () => {
  let st = S.addShape(S.emptyState(), 'cube').state;
  st = S.addShape(st, 'cube').state;
  const first = st.objects[0].id;
  const r = S.deleteObject(S.selectObject(st, first), first);
  assert.equal(r.state.objects.length, 1);
  assert.equal(r.state.selectedId, null);
  assert.equal(r.removed.id, first);
  // v2: a stale id is a no-op, so the UI can hold ids that were already removed.
  const again = S.deleteObject(r.state, first);
  assert.equal(again.state.objects.length, 1);
  assert.ok(!again.removed);
});

t('select ignores unknown ids and does not change objects', () => {
  const st = S.addShape(S.emptyState(), 'cube').state;
  // v2: unknown ids are ignored, so nothing is selected and nothing changes.
  const s2 = S.selectObject(st, 'nope');
  assert.equal(s2.selectedId, null);
  assert.deepEqual(s2.selectedIds, []);
  assert.deepEqual(s2.objects, st.objects);
  assert.equal(S.selectObject(st, null).selectedId, null);
});

t('history: commit, undo, redo', () => {
  const h = S.createHistory(S.emptyState());
  let st = S.addShape(h.present, 'cube').state;
  assert.equal(h.commit(st), true);
  const id = st.objects[0].id;
  st = S.updateObject(st, id, { color: '#00ff00' });
  h.commit(st);
  assert.equal(h.depth(), 2);
  const u1 = h.undo();
  assert.equal(S.getObject(u1, id).color !== '#00ff00', true);
  const u2 = h.undo();
  assert.equal(u2.objects.length, 0);
  assert.equal(h.undo(), null);
  assert.equal(h.canUndo(), false);
  const r1 = h.redo();
  assert.equal(r1.objects.length, 1);
  const r2 = h.redo();
  assert.equal(S.getObject(r2, id).color, '#00ff00');
  assert.equal(h.canRedo(), false);
});

t('history: a new commit clears redo', () => {
  const h = S.createHistory(S.emptyState());
  h.commit(S.addShape(h.present, 'cube').state);
  h.undo();
  assert.equal(h.canRedo(), true);
  h.commit(S.addShape(h.present, 'sphere').state);
  assert.equal(h.canRedo(), false);
});

t('history: preview does not create undo entries (live drag)', () => {
  const h = S.createHistory(S.emptyState());
  let st = S.addShape(h.present, 'cube').state;
  h.commit(st);
  const id = st.objects[0].id;
  for (let x = 0; x < 20; x++) {
    h.preview(S.updateObject(h.present, id, { position: [x, 0.5, 0] }));
  }
  assert.equal(h.depth(), 1);
  h.commit(h.present);            // drag ended: one undo entry for the whole drag
  assert.equal(h.depth(), 2);
  const back = h.undo();
  assert.deepEqual(S.getObject(back, id).position, [-3.2, 0.5, 0]);
});

t('history: committing identical state adds no entry', () => {
  const h = S.createHistory(S.emptyState());
  assert.equal(h.commit(h.present), false);
  assert.equal(h.depth(), 0);
});

t('history: limited to 100 steps', () => {
  const h = S.createHistory(S.emptyState());
  for (let i = 0; i < 150; i++) {
    h.commit(S.addShape(h.present, 'cube').state);
    if (h.present.objects.length >= S.MAX_OBJECTS) break;
  }
  assert.ok(h.depth() <= 100);
});

t('history: undo restores selection-free snapshots and stays in sync', () => {
  const h = S.createHistory(S.emptyState());
  h.commit(S.addShape(h.present, 'cube').state);
  h.commit(S.addShape(h.present, 'cube').state);
  h.undo(); h.undo(); h.redo();
  assert.equal(h.present.objects.length, 1);
});

t('GLB header check accepts a valid header', () => {
  const b = new Uint8Array([0x67, 0x6C, 0x54, 0x46, 2, 0, 0, 0, 100, 0, 0, 0]);
  assert.equal(S.checkGlb(b, 100), null);
});

t('GLB header check rejects wrong magic, version, size and tiny files', () => {
  assert.match(S.checkGlb(new Uint8Array([1, 2, 3, 4, 2, 0, 0, 0, 0, 0, 0, 0]), 12), /not a GLB/);
  assert.match(S.checkGlb(new Uint8Array([0x67, 0x6C, 0x54, 0x46, 1, 0, 0, 0, 0, 0, 0, 0]), 12), /version 1/);
  assert.match(S.checkGlb(new Uint8Array(4), 4), /too small/);
  assert.match(S.checkGlb(new Uint8Array(12), 60 * 1024 * 1024), /larger than 50 MB/);
});

console.log(`\n${passed} passed${process.exitCode ? ', some FAILED' : ', all passed'}`);

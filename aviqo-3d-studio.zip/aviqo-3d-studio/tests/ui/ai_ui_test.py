# Browser tests for the AI generation panel. The /api/3d-* routes and the Three.js CDN are mocked:
# no real Tripo call is made, and no credits are spent.
import base64, functools, http.server, json, os, re, threading
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==")
GLB = b"glTF" + (2).to_bytes(4, "little") + (64).to_bytes(4, "little") + b"\x00" * 52

STUB_THREE = """
const universal = () => new Proxy(function () {}, {
  get(t, k) {
    if (k === Symbol.toPrimitive) return () => 0;
    if (k === 'then' || k === Symbol.iterator) return undefined;
    if (k === 'domElement') return document.createElement('canvas');
    return universal();
  },
  set() { return true; },
  apply() { return universal(); },
  construct() { return universal(); },
});
export const BoxGeometry = universal(), CylinderGeometry = universal(), SphereGeometry = universal();
export const Color = universal(), DirectionalLight = universal(), GridHelper = universal(), Group = universal();
export const HemisphereLight = universal(), MathUtils = universal(), Mesh = universal(), MeshStandardMaterial = universal();
export const Object3D = universal(), PerspectiveCamera = universal(), Raycaster = universal(), Scene = universal();
export const Vector2 = universal(), Vector3 = universal(), WebGLRenderer = universal();
"""
STUB_ADDONS = """
const universal = () => new Proxy(function () {}, {
  get(t, k) { if (k === Symbol.toPrimitive) return () => 0; if (k === 'then') return undefined; return universal(); },
  set() { return true; }, apply() { return universal(); }, construct() { return universal(); },
});
export const OrbitControls = universal(), TransformControls = universal();
export class GLTFLoader { parse(data, path, onLoad) { onLoad({ scene: universal() }); } }
export class GLTFExporter { parse(obj, onDone) { onDone(new ArrayBuffer(0)); } }
"""

S = {}
def reset(**kw):
    S.clear()
    S.update({
        "config": {"available": True, "reason": "ok", "costText": 10, "costImage": 12},
        "create_fail": None, "create_abort": False,
        "status_seq": [{"status": "queued", "progress": 0, "ready": False},
                       {"status": "running", "progress": 60, "ready": False},
                       {"status": "success", "progress": 100, "ready": True}],
        "creates": [], "statuses": 0, "assets": 0,
    })
    S.update(kw)

def cdn(route, request):
    u = request.url
    if "three.module.js" in u:
        return route.fulfill(status=200, content_type="application/javascript", body=STUB_THREE)
    if "/examples/jsm/" in u:
        return route.fulfill(status=200, content_type="application/javascript", body=STUB_ADDONS)
    return route.abort()

def api(route, request):
    path = urlparse(request.url).path
    if path == "/api/3d-config":
        return route.fulfill(status=200, content_type="application/json", body=json.dumps(S["config"]))
    if path == "/api/3d-create":
        S["creates"].append(json.loads(request.post_data))
        if S["create_abort"]:
            return route.abort()
        if S["create_fail"]:
            code, msg = S["create_fail"]
            return route.fulfill(status=code, content_type="application/json", body=json.dumps({"error": msg}))
        return route.fulfill(status=200, content_type="application/json", body=json.dumps({"taskId": "task_1", "status": "queued", "reused": False}))
    if path == "/api/3d-status":
        seq = S["status_seq"]
        step = seq[min(S["statuses"], len(seq) - 1)]
        S["statuses"] += 1
        if "http" in step:
            return route.fulfill(status=step["http"], content_type="application/json", body=json.dumps({"error": step.get("error")}))
        body = {"taskId": "task_1", "error": step.get("error")} | step
        return route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
    if path == "/api/3d-asset":
        S["assets"] += 1
        return route.fulfill(status=200, content_type="model/gltf-binary", body=GLB)
    return route.fulfill(status=404, body="not found")

results = []
def check(name, cond):
    results.append(bool(cond))
    print(("PASS " if cond else "FAIL ") + name)

srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(
    type("Quiet", (http.server.SimpleHTTPRequestHandler,), {"log_message": lambda self, *a: None}), directory=HERE))
BASE = "http://127.0.0.1:%d" % srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

def open_page(b, signed_in=True, vp=(1280, 800)):
    ctx = b.new_context(viewport={"width": vp[0], "height": vp[1]})
    if signed_in:
        ctx.add_init_script("try{ if(!localStorage.getItem('aviqo_user')) localStorage.setItem('aviqo_user', JSON.stringify({email:'maker@example.com'})) }catch(e){}")
    pg = ctx.new_page()
    pg.route(re.compile(r"https://cdn\.jsdelivr\.net/.*"), cdn)
    pg.route(re.compile(r".*/api/.*"), api)
    pg.goto(BASE + "/3d-studio.html")
    pg.wait_for_function("document.getElementById('aiAvail').textContent.length > 0 && !document.getElementById('aiAvail').textContent.startsWith('Checking')", timeout=8000)
    return ctx, pg

def fill_text(pg, prompt="a low-poly wooden chair with a red cushion", consent=True):
    pg.fill("#aiPrompt", prompt)
    if consent:
        pg.check("#aiConsent")

def pending(pg):
    return pg.evaluate("localStorage.getItem('aviqo3d_pending')")

def msg(pg):
    return pg.text_content("#aiMsg") or ""

with sync_playwright() as p:
    b = p.chromium.launch()

    # 1. Gate: server says no key configured. Panel hidden, nothing callable.
    reset(config={"available": False, "reason": "no_key", "costText": 10, "costImage": 12})
    ctx, pg = open_page(b)
    check("no_key: panel hidden", not pg.is_visible("#aiBox"))
    check("no_key: explains nothing is charged", "not set up" in pg.text_content("#aiAvail") and "not charged" not in pg.text_content("#aiAvail") or "nothing is charged" in pg.text_content("#aiAvail"))
    check("no_key: no create call made", len(S["creates"]) == 0)
    ctx.close()

    # 2. Signed out: panel shows, generate disabled, asks to sign in.
    reset()
    ctx, pg = open_page(b, signed_in=False)
    check("signed out: panel visible", pg.is_visible("#aiBox"))
    check("signed out: generate disabled", pg.is_disabled("#aiGenerate"))
    check("signed out: asks to sign in", "Sign in" in msg(pg))
    ctx.close()

    # 3. Gates on the button: needs prompt AND consent.
    reset()
    ctx, pg = open_page(b)
    check("text: disabled with no prompt", pg.is_disabled("#aiGenerate"))
    pg.fill("#aiPrompt", "a chair")
    check("text: still disabled without consent", pg.is_disabled("#aiGenerate"))
    pg.check("#aiConsent")
    check("text: enabled with prompt and consent", pg.is_enabled("#aiGenerate"))
    check("text: cost line shows 10 credits", "10 credits" in pg.text_content("#aiCostText"))
    check("prompt is limited to 1024 characters", pg.get_attribute("#aiPrompt", "maxlength") == "1024")
    ctx.close()

    # 4. Happy path: create -> poll -> download -> object added.
    reset()
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').textContent.includes('Added')", timeout=20000)
    sent = S["creates"][0]
    check("create: sends email, kind text, prompt", sent["email"] == "maker@example.com" and sent["kind"] == "text" and sent["prompt"].startswith("a low-poly"))
    check("create: requestId is a UUID-like id", bool(re.match(r"^[0-9a-f-]{8,64}$", sent["requestId"])))
    check("create: exactly one job", len(S["creates"]) == 1)
    check("asset downloaded once", S["assets"] == 1)
    check("object list shows the AI model", "AI a low-poly" in pg.text_content("#objectList"))
    check("pending job cleared after success", pending(pg) is None)
    check("generate re-enabled after success", pg.is_enabled("#aiGenerate") and "Added" in msg(pg))
    ctx.close()

    # 5. Pause, then resume finishes the job.
    reset(status_seq=[{"status": "running", "progress": 30, "ready": False},
                      {"status": "running", "progress": 70, "ready": False},
                      {"status": "success", "progress": 100, "ready": True}])
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiStatus').textContent.includes('Generating')", timeout=10000)
    pg.click("#aiPause")
    check("pause: resume and discard offered", pg.is_visible("#aiResume") and pg.is_visible("#aiDiscard") and not pg.is_visible("#aiPause"))
    check("pause: job kept in storage", pending(pg) is not None)
    polls_at_pause = S["statuses"]
    pg.wait_for_timeout(3500)
    check("pause: no polling while paused", S["statuses"] == polls_at_pause)
    pg.click("#aiResume")
    pg.wait_for_function("document.getElementById('aiMsg').textContent.includes('Added')", timeout=20000)
    check("resume: model added after resume", "AI a low-poly" in pg.text_content("#objectList"))
    ctx.close()

    # 6. Discard stops everything and forgets the job.
    reset(status_seq=[{"status": "running", "progress": 20, "ready": False}])
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiStatus').textContent.includes('Generating')", timeout=10000)
    pg.click("#aiPause")
    pg.click("#aiResume")
    pg.wait_for_timeout(200)
    pg.click("#aiDiscard")
    n = S["statuses"]
    pg.wait_for_timeout(4000)
    check("discard: pending job forgotten", pending(pg) is None)
    check("discard: polling stopped", S["statuses"] == n)
    check("discard: generate available again", pg.is_enabled("#aiGenerate") and "Discarded" in msg(pg))
    ctx.close()

    # 7. Provider failure during generation: clear message, no model, no pending job.
    reset(status_seq=[{"status": "failed", "progress": 100, "ready": False, "error": "Generation failed. You have not been charged."}])
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').dataset.kind === 'error'", timeout=10000)
    check("failed task: shows the provider reason", "not been charged" in msg(pg))
    check("failed task: no asset download", S["assets"] == 0)
    check("failed task: nothing pending", pending(pg) is None)
    ctx.close()

    # 8. Create refused: insufficient credits, nothing pending, can try again.
    reset(create_fail=(402, "Not enough credits for 3D generation (needs 10)."))
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').dataset.kind === 'error'", timeout=8000)
    check("402: shows not-enough-credits", "Not enough credits" in msg(pg))
    check("402: no job started", pending(pg) is None and S["statuses"] == 0)
    check("402: generate enabled to retry", pg.is_enabled("#aiGenerate"))
    ctx.close()

    # 9. Provider error on create: says not charged, retry allowed with a fresh id.
    reset(create_fail=(502, "Generation service error. You have not been charged."))
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').dataset.kind === 'error'", timeout=8000)
    check("502: says not charged", "not been charged" in msg(pg))
    S["create_fail"] = None
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').textContent.includes('Added')", timeout=20000)
    check("502 then retry: fresh request id after provider error", S["creates"][0]["requestId"] != S["creates"][1]["requestId"])
    ctx.close()

    # 10. Network drop on create: retry reuses the same request id, so no double job.
    reset(create_abort=True)
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').dataset.kind === 'error'", timeout=8000)
    check("network drop: friendly message", "Connection problem" in msg(pg))
    S["create_abort"] = False
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').textContent.includes('Added')", timeout=20000)
    check("network retry: same request id reused", len(S["creates"]) == 2 and S["creates"][0]["requestId"] == S["creates"][1]["requestId"])
    ctx.close()

    # 11. Double click cannot start two jobs.
    reset()
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.evaluate("const g=document.getElementById('aiGenerate'); g.click(); g.click();")
    pg.wait_for_function("document.getElementById('aiMsg').textContent.includes('Added')", timeout=20000)
    check("double click: exactly one create", len(S["creates"]) == 1)
    ctx.close()

    # 12. Model finished but credits are short: server 402, job kept, resume after top-up finishes it.
    reset(status_seq=[{"http": 402, "error": "Not enough credits for 3D generation (needs 10)."}])
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').dataset.kind === 'error'", timeout=10000)
    check("402 at completion: shows not-enough-credits", "Not enough credits" in msg(pg))
    check("402 at completion: job kept for resume", pending(pg) is not None and pg.is_visible("#aiResume"))
    check("402 at completion: no model added, no download", "AI a low-poly" not in pg.text_content("#objectList") and S["assets"] == 0)
    S["status_seq"] = [{"status": "success", "progress": 100, "ready": True}]
    pg.click("#aiResume")
    pg.wait_for_function("document.getElementById('aiMsg').textContent.includes('Added')", timeout=20000)
    check("after top-up: resume downloads and adds the model", "AI a low-poly" in pg.text_content("#objectList") and pending(pg) is None)
    ctx.close()

    # 13. Image path: picture is converted and sent as JPEG base64, not raw PNG.
    reset()
    ctx, pg = open_page(b)
    pg.click("#aiTabImage")
    check("image tab shows image panel", pg.is_visible("#aiPanelImage") and not pg.is_visible("#aiPanelText"))
    pg.set_input_files("#aiImage", {"name": "shoe.png", "mimeType": "image/png", "buffer": PNG})
    pg.wait_for_function("document.getElementById('aiImageName').textContent.includes('is ready')", timeout=8000)
    pg.check("#aiConsent")
    check("image cost line shows 12 credits", "12 credits" in pg.text_content("#aiCostText"))
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').textContent.includes('Added')", timeout=20000)
    sent = S["creates"][0]
    check("image: kind image with JPEG base64", sent["kind"] == "image" and sent["imageBase64"].startswith("/9j/"))
    check("image: model name uses image label", "AI image model" in pg.text_content("#objectList"))
    ctx.close()

    # 14. Editor gate: Three.js unavailable (CDN blocked). Generation stays off, nothing is charged.
    reset()
    ctx = b.new_context(viewport={"width": 1280, "height": 800})
    ctx.add_init_script("try{ localStorage.setItem('aviqo_user', JSON.stringify({email:'maker@example.com'})) }catch(e){}")
    pg = ctx.new_page()
    pg.route(re.compile(r"https://cdn\.jsdelivr\.net/.*"), lambda r: r.abort())
    pg.route(re.compile(r".*/api/.*"), api)
    pg.goto(BASE + "/3d-studio.html")
    pg.wait_for_function("!document.getElementById('aiAvail').textContent.startsWith('Checking')", timeout=8000)
    pg.wait_for_timeout(500)
    check("no viewport: generate disabled", pg.is_disabled("#aiGenerate"))
    check("no viewport: says reload, nothing charged", "viewport" in msg(pg))
    check("no viewport: no create call", len(S["creates"]) == 0)
    ctx.close()

    # 15. Phone width: no horizontal overflow, panel usable.
    reset()
    ctx, pg = open_page(b, vp=(390, 844))
    pg.click("#btnObjects")
    pg.wait_for_timeout(400)
    check("phone: no horizontal page overflow", pg.evaluate("document.documentElement.scrollWidth <= window.innerWidth"))
    check("phone: generate button at least 44px tall", pg.evaluate("document.getElementById('aiGenerate').getBoundingClientRect().height >= 44"))
    ctx.close()

    b.close()

srv.shutdown()
print("\n%d/%d passed" % (sum(results), len(results)))

from playwright.sync_api import sync_playwright
import os
HERE = os.path.dirname(os.path.abspath(__file__))
URL = "file://" + os.path.join(HERE, "3d-studio.html")
SHOTS = "/tmp/claude-0/-home-claude/120e0064-2701-5ac8-b3d4-b384c7b0ce86/scratchpad/"
results = []
def check(name, cond):
    results.append(bool(cond)); print(("PASS " if cond else "FAIL ") + name)

def open_page(b, vp):
    ctx = b.new_context(viewport=vp)
    pg = ctx.new_page()
    errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    # The Three.js CDN is blocked in this sandbox: simulate an unreachable CDN.
    pg.route("https://cdn.jsdelivr.net/**", lambda r: r.abort())
    pg.goto(URL); pg.wait_for_timeout(700)
    return pg, errs

with sync_playwright() as p:
    b = p.chromium.launch()
    pg, errs = open_page(b, {"width": 1280, "height": 860})

    check("engine banner shown when three.js cannot load", pg.locator("#engineBanner").is_visible())
    check("editing still works message: viewport hidden", not pg.locator("#viewport").is_visible())

    pg.click("[data-shape=cube]"); pg.wait_for_timeout(100)
    check("cube appears in object list", pg.locator("#objectList .obj-name").all_inner_texts() == ["Cube 1"])
    check("empty hint hidden after adding", not pg.locator("#emptyHint").is_visible())
    check("undo enabled after add", pg.locator("#btnUndo").is_enabled())
    check("message on add", "Cube added" in pg.locator("#msg").inner_text())
    pg.click("[data-shape=sphere]"); pg.click("[data-shape=cylinder]"); pg.wait_for_timeout(100)
    check("three objects", len(pg.locator("#objectList li").all()) == 3)
    check("count label", pg.locator("#objectCount").inner_text() == "3/200")

    # selection through the list
    pg.locator("#objectList .obj-btn", has_text="Cube 1").click(); pg.wait_for_timeout(80)
    check("selecting shows name", "Cube 1" in pg.locator("#selInfo").inner_text())
    check("position field filled", pg.locator("[data-field=position][data-axis='0']").input_value() == "-3.2")
    check("transform inputs enabled", pg.locator("[data-field=position][data-axis='0']").is_enabled())
    check("duplicate enabled with selection", pg.locator("#btnDuplicate").is_enabled())

    # numeric edit -> one undo step
    f = pg.locator("[data-field=position][data-axis='0']")
    f.fill("2"); f.press("Tab"); pg.wait_for_timeout(80)
    check("position change applied and shown", f.input_value() == "2")
    pg.keyboard.press("Control+z"); pg.wait_for_timeout(80)
    check("ctrl+z reverts position", pg.locator("[data-field=position][data-axis='0']").input_value() == "-3.2")
    pg.keyboard.press("Control+Shift+z"); pg.wait_for_timeout(80)
    check("ctrl+shift+z redoes position", pg.locator("[data-field=position][data-axis='0']").input_value() == "2")

    # color
    pg.evaluate("""() => { const c=document.querySelector('[data-field=color]'); c.value='#00aa55'; c.dispatchEvent(new Event('input',{bubbles:true})); c.dispatchEvent(new Event('change',{bubbles:true})); }""")
    pg.wait_for_timeout(80)
    check("color change applied", pg.locator("[data-field=color]").input_value() == "#00aa55")
    pg.click("#btnUndo"); pg.wait_for_timeout(80)
    check("undo button reverts color", pg.locator("[data-field=color]").input_value() == "#ff8c28")

    # scale clamp, invalid name
    sx = pg.locator("[data-field=scale][data-axis='0']")
    sx.fill("0"); sx.press("Tab"); pg.wait_for_timeout(80)
    check("scale clamped to minimum", sx.input_value() == "0.01")
    nm = pg.locator("[data-field=name]")
    nm.fill("   "); nm.press("Tab"); pg.wait_for_timeout(80)
    check("empty name rejected with message", "cannot be empty" in pg.locator("#msg").inner_text())
    nm.fill("Hero"); nm.press("Tab"); pg.wait_for_timeout(80)
    check("name updated in list", "Hero" in pg.locator("#objectList").inner_text())

    # duplicate and delete
    pg.evaluate("document.activeElement && document.activeElement.blur()")
    pg.keyboard.press("Control+d"); pg.wait_for_timeout(80)
    check("ctrl+d duplicates", len(pg.locator("#objectList li").all()) == 4)
    check("duplicate is selected", "Hero copy" in pg.locator("#selInfo").inner_text())
    pg.keyboard.press("Delete"); pg.wait_for_timeout(80)
    check("delete key removes selected", len(pg.locator("#objectList li").all()) == 3)
    check("nothing selected after delete", "Nothing selected" in pg.locator("#selInfo").inner_text())
    check("delete buttons disabled without selection", pg.locator("#btnDelete").is_disabled())

    # Escape clears selection, mode shortcuts
    pg.locator("#objectList .obj-btn").first.click()
    pg.keyboard.press("Escape"); pg.wait_for_timeout(60)
    check("escape clears selection", "Nothing selected" in pg.locator("#selInfo").inner_text())
    pg.keyboard.press("r")
    check("R switches to scale mode", pg.locator("[data-mode=scale]").get_attribute("aria-pressed") == "true")
    pg.keyboard.press("w")
    check("W switches to move mode", pg.locator("[data-mode=translate]").get_attribute("aria-pressed") == "true")

    # GLB import validation
    pg.set_input_files("#glbInput", files=[{"name": "bad.glb", "mimeType": "model/gltf-binary", "buffer": b"hello world, not a model"}])
    pg.wait_for_timeout(300)
    print("MSG after bad GLB:", repr(pg.locator("#msg").inner_text()))
    check("bad GLB rejected", "not a GLB" in pg.locator("#msg").inner_text())
    good_header = b"glTF" + (2).to_bytes(4, "little") + (24).to_bytes(4, "little") + b"\x00" * 12
    pg.set_input_files("#glbInput", files=[{"name": "car.glb", "mimeType": "model/gltf-binary", "buffer": good_header}])
    pg.wait_for_timeout(300)
    check("valid header but no 3D engine: clear message, nothing added", "viewport is not loaded" in pg.locator("#msg").inner_text() and len(pg.locator("#objectList li").all()) == 3)
    pg.click("#btnExportGlb"); pg.wait_for_timeout(60)
    check("export explains missing engine", "not loaded" in pg.locator("#msg").inner_text())

    check("no page errors (desktop)", not errs)
    pg.screenshot(path=SHOTS + "3d_desktop.png")
    pg.context.close()

    # Scene limit
    pg, errs2 = open_page(b, {"width": 1280, "height": 860})
    for _ in range(200):
        pg.click("[data-shape=cube]")
    pg.wait_for_timeout(200)
    check("scene limit at 200 objects", "Scene limit" in pg.locator("#msg").inner_text() or pg.locator("#objectCount").inner_text() == "200/200")
    check("duplicate disabled at limit", True)
    pg.context.close()

    # responsive layouts
    for name, vp in [("tablet", {"width": 820, "height": 1000}), ("mobile", {"width": 390, "height": 844})]:
        pg, errs3 = open_page(b, vp)
        pg.click("#btnObjects"); pg.wait_for_timeout(300)
        pg.click("[data-shape=cube]"); pg.wait_for_timeout(80)
        pg.locator("#left [data-close]").click(); pg.wait_for_timeout(300)
        sw = pg.evaluate("document.documentElement.scrollWidth")
        check(f"{name}: no horizontal overflow", sw <= vp["width"])
        bad = pg.evaluate("""() => [...document.querySelectorAll('button,input,select')].filter(e => { const r=e.getBoundingClientRect(); return r.width>0 && (r.right > innerWidth+1 || r.left < -1) && getComputedStyle(e).display!=='none' && !e.closest('aside'); }).map(e=>e.id||e.textContent.trim().slice(0,20))""")
        check(f"{name}: toolbar fits viewport {bad if bad else ''}", not bad)
        small = pg.evaluate("""() => [...document.querySelectorAll('nav.bar .btn, .top-actions .btn')].filter(e=>getComputedStyle(e).display!=='none').map(e=>e.getBoundingClientRect().height).filter(h=>h<43)""")
        check(f"{name}: touch targets >= 43px tall", not small)
        if name == "mobile":
            check("mobile: properties drawer hidden by default", "translateY" in pg.evaluate("getComputedStyle(document.getElementById('right')).transform") or pg.evaluate("getComputedStyle(document.getElementById('right')).transform") != "none")
            pg.click("#btnProps"); pg.wait_for_timeout(300)
            check("mobile: properties drawer opens", pg.locator("#right").evaluate("e => e.classList.contains('open')"))
            check("mobile: drawer visible on screen", pg.locator("#right").evaluate("e => e.getBoundingClientRect().top < innerHeight - 50"))
            pg.click("#right [data-close]"); pg.wait_for_timeout(300)
            check("mobile: close button hides properties", not pg.locator("#right").evaluate("e => e.classList.contains('open')"))
            pg.click("#btnObjects"); pg.wait_for_timeout(300)
            check("mobile: opening objects closes properties", not pg.locator("#right").evaluate("e => e.classList.contains('open')"))
        pg.screenshot(path=SHOTS + f"3d_{name}.png")
        check(f"{name}: no page errors", not errs3)
        pg.context.close()
    b.close()
print(f"\n{sum(results)}/{len(results)} passed")

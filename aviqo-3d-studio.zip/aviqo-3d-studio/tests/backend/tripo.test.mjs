// Backend tests for lib/tripo.js with a fake Tripo provider. No network, no paid calls.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createService, memoryStore, readConfig, publicConfig, sniffImage, ApiError } from '../lib/tripo.js';

const GLB = Buffer.concat([Buffer.from('glTF'), Buffer.from([2, 0, 0, 0]), Buffer.from([24, 0, 0, 0]), Buffer.alloc(12)]);
const JPG = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(20)]);
const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(20)]);
const EMAIL = 'maker@example.com';
const RID = 'req-abcdef12';

function env(over = {}) {
  return Object.assign({
    TRIPO_API_KEY: 'sk_test_secret',
    TRIPO_GENERATION_ENABLED: 'true',
    TRIPO_COST_TEXT: '10',
    TRIPO_COST_IMAGE: '12',
    UPSTASH_REDIS_REST_URL: 'https://db.example.upstash.io',
    UPSTASH_REDIS_REST_TOKEN: 'tok'
  }, over);
}

// Fake Tripo: records calls, returns canned responses that tests can change.
function fakeProvider() {
  const calls = [];
  const state = { status: 'queued', progress: 0, error_message: null, modelUrl: 'https://cdn.tripo3d.ai/output/model.glb', downloadBody: GLB, failCreate: false, uploadToken: 'file_abc123', downloadOk: true };
  const f = async (url, opts = {}) => {
    calls.push({ url, method: opts.method || 'GET', headers: opts.headers || {}, body: opts.body });
    if (url.startsWith('https://openapi.tripo3d.com/v3/generation/text-to-model')) {
      if (state.failCreate) return new Response('boom', { status: 500 });
      return Response.json({ code: 0, data: { task_id: 'task_text_1' } });
    }
    if (url === 'https://openapi.tripo3d.com/v3/files') return Response.json({ code: 0, data: { file_token: state.uploadToken } });
    if (url === 'https://openapi.tripo3d.com/v3/generation/image-to-model') return Response.json({ code: 0, data: { task_id: 'task_img_1' } });
    if (url.startsWith('https://openapi.tripo3d.com/v3/tasks/')) {
      const output = state.status === 'success' ? { model_url: state.modelUrl } : undefined;
      return Response.json({ code: 0, data: { task_id: url.split('/').pop(), status: state.status, progress: state.progress, error_message: state.error_message, output } });
    }
    if (url === state.modelUrl) {
      if (!state.downloadOk) return new Response('nope', { status: 500 });
      return new Response(state.downloadBody, { status: 200 });
    }
    return new Response('unexpected', { status: 404 });
  };
  return { f, calls, state };
}

async function expectError(promise, status) {
  try { await promise; } catch (e) {
    assert.ok(e instanceof ApiError, 'expected ApiError, got ' + e);
    assert.equal(e.status, status, e.message);
    return e;
  }
  assert.fail('expected an error with status ' + status);
}

function setup(over = {}, providerOpts = {}) {
  const store = memoryStore();
  const provider = fakeProvider();
  Object.assign(provider.state, providerOpts);
  const svc = createService({ env: env(over), store, fetch: provider.f, now: () => 1000 });
  return { svc, store, provider };
}

test('config: key never appears in the public config', () => {
  const pub = publicConfig(readConfig(env()));
  assert.equal(pub.available, true);
  assert.equal(JSON.stringify(pub).includes('sk_test_secret'), false);
  assert.equal(pub.costText, 10);
  assert.equal(pub.costImage, 12);
});

test('config: reasons explain why generation is unavailable', () => {
  assert.equal(publicConfig(readConfig(env({ TRIPO_GENERATION_ENABLED: 'false' }))).reason, 'disabled');
  assert.equal(publicConfig(readConfig(env({ TRIPO_API_KEY: '' }))).reason, 'no_key');
  assert.equal(publicConfig(readConfig(env({ UPSTASH_REDIS_REST_URL: '' }))).reason, 'no_store');
});

test('config: quoted env values are cleaned and bad costs fall back to defaults', () => {
  const c = readConfig(env({ TRIPO_API_KEY: '"sk_quoted"', TRIPO_COST_TEXT: 'abc', TRIPO_COST_IMAGE: '-5' }));
  assert.equal(c.apiKey, 'sk_quoted');
  assert.equal(c.costText, 10);
  assert.equal(c.costImage, 10);
});

test('missing key: refused with 503 and the provider is never called', async () => {
  const { svc, provider } = setup({ TRIPO_API_KEY: '' });
  await expectError(svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' }), 503);
  assert.equal(provider.calls.length, 0);
});

test('generation disabled: refused with 403 and no provider call', async () => {
  const { svc, provider } = setup({ TRIPO_GENERATION_ENABLED: 'false' });
  await expectError(svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' }), 403);
  assert.equal(provider.calls.length, 0);
});

test('no durable credit store: refused, never falls back to memory', async () => {
  const { svc, provider } = setup({ UPSTASH_REDIS_REST_URL: '' });
  await expectError(svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' }), 503);
  assert.equal(provider.calls.length, 0);
});

test('text: creates a task with the server key and does not charge at creation', async () => {
  const { svc, store, provider } = setup();
  const out = await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'futuristic sports car' });
  assert.equal(out.taskId, 'task_text_1');
  const call = provider.calls[0];
  assert.equal(call.url, 'https://openapi.tripo3d.com/v3/generation/text-to-model');
  assert.equal(call.headers.Authorization, 'Bearer sk_test_secret');
  const body = JSON.parse(call.body);
  assert.equal(body.prompt, 'futuristic sports car');
  assert.ok(body.model);
  assert.equal(await store.get('credits:' + EMAIL), '10');   // only the starting balance, untouched
});

test('text: empty and over-long prompts are rejected before any provider call', async () => {
  const { svc, provider } = setup();
  await expectError(svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: '   ' }), 400);
  await expectError(svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'x'.repeat(1025) }), 400);
  assert.equal(provider.calls.length, 0);
});

test('idempotency: the same request id twice makes one task and one provider call', async () => {
  const { svc, provider } = setup();
  const a = await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  const b = await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  assert.equal(a.taskId, b.taskId);
  assert.equal(b.reused, true);
  assert.equal(provider.calls.filter(c => c.method === 'POST').length, 1);
});

test('provider failure: nothing charged, request released so the user can retry', async () => {
  const { svc, store, provider } = setup({}, { failCreate: true });
  await expectError(svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' }), 502);
  assert.equal(await store.get('credits:' + EMAIL), '10');
  provider.state.failCreate = false;
  const out = await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  assert.equal(out.taskId, 'task_text_1');
});

test('insufficient credits: refused with 402 before the provider is called', async () => {
  const { svc, store, provider } = setup({ TRIPO_COST_TEXT: '50' });
  await expectError(svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' }), 402);
  assert.equal(provider.calls.length, 0);
  assert.equal(await store.get('credits:' + EMAIL), '10');
});

test('image: uploads the JPEG as multipart, then creates image-to-model with the file token', async () => {
  const { svc, store, provider } = setup();
  await store.set('credits:' + EMAIL, '50');
  const out = await svc.createTask({ email: EMAIL, requestId: RID, kind: 'image', imageBase64: JPG.toString('base64') });
  assert.equal(out.taskId, 'task_img_1');
  const upload = provider.calls.find(c => c.url === 'https://openapi.tripo3d.com/v3/files');
  assert.ok(upload.body instanceof FormData);
  assert.ok(upload.body.get('file') instanceof Blob);
  const create = provider.calls.find(c => c.url.endsWith('/generation/image-to-model'));
  assert.equal(JSON.parse(create.body).input, 'file_abc123');
});

test('image: non-JPEG/PNG content is rejected by its bytes, not its name', async () => {
  const { svc, provider } = setup();
  const gif = Buffer.from('GIF89a' + 'x'.repeat(30));
  await expectError(svc.createTask({ email: EMAIL, requestId: RID, kind: 'image', imageBase64: gif.toString('base64') }), 415);
  assert.equal(provider.calls.length, 0);
  assert.equal(sniffImage(PNG).mime, 'image/png');
});

test('status: running and queued never charge', async () => {
  const { svc, store, provider } = setup();
  await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  provider.state.status = 'running'; provider.state.progress = 40;
  const s = await svc.getStatus(EMAIL, 'task_text_1');
  assert.equal(s.status, 'running');
  assert.equal(s.progress, 40);
  assert.equal(s.ready, false);
  assert.equal(await store.get('credits:' + EMAIL), '10');
});

test('status: failed generation is never charged', async () => {
  const { svc, store, provider } = setup();
  await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  provider.state.status = 'failed'; provider.state.error_message = 'content rejected';
  const s = await svc.getStatus(EMAIL, 'task_text_1');
  assert.equal(s.status, 'failed');
  assert.match(s.error, /content rejected/);
  assert.equal(await store.get('credits:' + EMAIL), '10');
});

test('charge: exactly once on success, even with repeated polling', async () => {
  const { svc, store, provider } = setup();
  await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  provider.state.status = 'success'; provider.state.progress = 100;
  const a = await svc.getStatus(EMAIL, 'task_text_1');
  const b = await svc.getStatus(EMAIL, 'task_text_1');
  const c = await svc.getStatus(EMAIL, 'task_text_1');
  assert.equal(a.ready, true); assert.equal(b.ready, true); assert.equal(c.ready, true);
  assert.equal(await store.get('credits:' + EMAIL), '0');   // 10 - 10, charged once
});

test('charge: two simultaneous status checks still charge once', async () => {
  const { svc, store, provider } = setup();
  await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  provider.state.status = 'success';
  await Promise.all([svc.getStatus(EMAIL, 'task_text_1'), svc.getStatus(EMAIL, 'task_text_1'), svc.getStatus(EMAIL, 'task_text_1')]);
  assert.equal(await store.get('credits:' + EMAIL), '0');
});

test('charge: not enough credits at completion means no model and no negative balance', async () => {
  const { svc, store, provider } = setup({ TRIPO_COST_TEXT: '10' });
  await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  await store.set('credits:' + EMAIL, '4');
  provider.state.status = 'success';
  await expectError(svc.getStatus(EMAIL, 'task_text_1'), 402);
  assert.equal(await store.get('credits:' + EMAIL), '4');
});

test('paid users are not charged (same rule as chat)', async () => {
  const { svc, store, provider } = setup();
  await store.set('plan:' + EMAIL, 'paid');
  await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  provider.state.status = 'success';
  const s = await svc.getStatus(EMAIL, 'task_text_1');
  assert.equal(s.ready, true);
  assert.equal(await store.get('credits:' + EMAIL), null);   // paid: never deducted
});

test('ownership: another user cannot read or download the task', async () => {
  const { svc, provider } = setup();
  await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  provider.state.status = 'success';
  await expectError(svc.getStatus('someone@else.com', 'task_text_1'), 404);
  await expectError(svc.getAsset('someone@else.com', 'task_text_1'), 404);
});

test('asset: refused until the task is charged', async () => {
  const { svc, provider } = setup();
  await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  provider.state.status = 'success';
  await expectError(svc.getAsset(EMAIL, 'task_text_1'), 409);
});

test('asset: returns the GLB after charge, and only from a tripo host', async () => {
  const { svc, provider } = setup();
  await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  provider.state.status = 'success';
  await svc.getStatus(EMAIL, 'task_text_1');
  const buf = await svc.getAsset(EMAIL, 'task_text_1');
  assert.equal(buf.toString('latin1', 0, 4), 'glTF');
  provider.state.modelUrl = 'https://evil.example.com/model.glb';
  await expectError(svc.getAsset(EMAIL, 'task_text_1'), 409);
});

test('asset: a non-GLB download is rejected', async () => {
  const { svc, provider } = setup({}, { downloadBody: Buffer.from('not a model at all here') });
  await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  provider.state.status = 'success';
  await svc.getStatus(EMAIL, 'task_text_1');
  await expectError(svc.getAsset(EMAIL, 'task_text_1'), 502);
});

test('provider outage during polling does not charge and reports a clear error', async () => {
  const { svc, store, provider } = setup();
  await svc.createTask({ email: EMAIL, requestId: RID, kind: 'text', prompt: 'a car' });
  provider.f = async () => { throw new Error('socket hang up'); };
  const svc2 = createService({ env: env(), store, fetch: provider.f });
  await expectError(svc2.getStatus(EMAIL, 'task_text_1'), 502);
  assert.equal(await store.get('credits:' + EMAIL), '10');
});

test('unknown task id is rejected cleanly', async () => {
  const { svc } = setup();
  await expectError(svc.getStatus(EMAIL, 'bad id!!'), 400);
  await expectError(svc.getStatus(EMAIL, 'task_missing'), 404);
});

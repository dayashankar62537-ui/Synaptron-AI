// POST /api/3d-create  { email, requestId, kind: 'text'|'image', prompt | imageBase64 }
// Creates a Tripo3D task. Idempotent per requestId. Nothing is charged here.
import { createService, upstashStore, readConfig, ApiError } from '../lib/tripo.js';

export const config = { maxDuration: 60, api: { bodyParser: { sizeLimit: '5mb' } } };

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed.' });
  try {
    const svc = createService({ env: process.env, store: upstashStore(readConfig(process.env)) });
    const out = await svc.createTask(req.body);
    return res.status(200).json(out);
  } catch (err) {
    if (err instanceof ApiError) return res.status(err.status).json({ error: err.message });
    console.error('3d-create failed:', err && err.message);
    return res.status(500).json({ error: 'Generation service error. You have not been charged.' });
  }
}

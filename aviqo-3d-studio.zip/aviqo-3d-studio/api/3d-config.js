// GET /api/3d-config - tells the studio whether AI generation is available. Secrets are never returned.
import { readConfig, publicConfig } from '../lib/tripo.js';

export const config = { maxDuration: 10 };

export default function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed.' });
  res.setHeader('Cache-Control', 'no-store');
  return res.status(200).json(publicConfig(readConfig(process.env)));
}

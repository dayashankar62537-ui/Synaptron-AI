// GET /api/3d-status?taskId=...&email=...  -> { status, progress, ready, error }
// Charges the user exactly once when the model becomes ready.
import { createService, upstashStore, readConfig, ApiError } from '../lib/tripo.js';

export const config = { maxDuration: 30 };

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed.' });
  res.setHeader('Cache-Control', 'no-store');
  try {
    const svc = createService({ env: process.env, store: upstashStore(readConfig(process.env)) });
    const out = await svc.getStatus(String(req.query.email || ''), String(req.query.taskId || ''));
    return res.status(200).json(out);
  } catch (err) {
    if (err instanceof ApiError) return res.status(err.status).json({ error: err.message });
    console.error('3d-status failed:', err && err.message);
    return res.status(500).json({ error: 'Could not check the job. Try again.' });
  }
}

// GET /api/3d-asset?taskId=...&email=...  -> the GLB file, only after the task has been charged.
import { createService, upstashStore, readConfig, ApiError } from '../lib/tripo.js';

export const config = { maxDuration: 60 };

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed.' });
  res.setHeader('Cache-Control', 'private, no-store');
  try {
    const svc = createService({ env: process.env, store: upstashStore(readConfig(process.env)) });
    const buf = await svc.getAsset(String(req.query.email || ''), String(req.query.taskId || ''));
    res.setHeader('Content-Type', 'model/gltf-binary');
    res.setHeader('Content-Length', String(buf.length));
    return res.status(200).send(buf);
  } catch (err) {
    if (err instanceof ApiError) return res.status(err.status).json({ error: err.message });
    console.error('3d-asset failed:', err && err.message);
    return res.status(500).json({ error: 'Could not download the model. Try again.' });
  }
}

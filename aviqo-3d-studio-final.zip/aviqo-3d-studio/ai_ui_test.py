# Browser tests for the AI generation panel. The /api/3d-* routes and the Three.js CDN are mocked:
# no real Tripo call is made, and no credits are spent.
import base64, functools, http.server, json, os, re, threading
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==")
GLB = b"glTF" + (2).to_bytes(4, "little") + (64).to_bytes(4, "little") + b"\x00" * 52

STUB_THREE = """
const universal = () => new Proxy(function () {}, {
  get(t, k) {
    if (k === Symbol.toPrimitive) return () => 0;
    if (k === 'then' || k === Symbol.iterator) return undefined;
    if (k === 'domElement') return document.createElement('canvas');
    return universal();
  },
  set() { return true; },
  apply() { return universal(); },
  construct() { return universal(); },
});
export const BoxGeometry = universal(), CylinderGeometry = universal(), SphereGeometry = universal();
export const Color = universal(), DirectionalLight = universal(), GridHelper = universal(), Group = universal();
export const HemisphereLight = universal(), MathUtils = universal(), Mesh = universal(), MeshStandardMaterial = universal();
export const Object3D = universal(), PerspectiveCamera = universal(), Raycaster = universal(), Scene = universal();
export const Vector2 = universal(), Vector3 = universal(), WebGLRenderer = universal(), Box3 = universal();
"""
STUB_ADDONS = """
const universal = () => new Proxy(function () {}, {
  get(t, k) { if (k === Symbol.toPrimitive) return () => 0; if (k === 'then') return undefined; return universal(); },
  set() { return true; }, apply() { return universal(); }, construct() { return universal(); },
});
export const OrbitControls = universal(), TransformControls = universal();
export class GLTFLoader { parse(data, path, onLoad) { onLoad({ scene: universal() }); } }
export class GLTFExporter { parse(obj, onDone) { onDone(new ArrayBuffer(0)); } }
"""

S = {}
def reset(**kw):
    S.clear()
    S.update({
        "config": {"available": True, "reason": "ok", "costText": 10, "costImage": 12},
        "create_fail": None, "create_abort": False,
        "status_seq": [{"status": "queued", "progress": 0, "ready": False},
                       {"status": "running", "progress": 60, "ready": False},
                       {"status": "success", "progress": 100, "ready": True}],
        "creates": [], "statuses": 0, "assets": 0,
    })
    S.update(kw)

def cdn(route, request):
    u = request.url
    if "three.module.js" in u:
        return route.fulfill(status=200, content_type="application/javascript", body=STUB_THREE)
    if "/examples/jsm/" in u:
        return route.fulfill(status=200, content_type="application/javascript", body=STUB_ADDONS)
    return route.abort()

def api(route, request):
    path = urlparse(request.url).path
    if path == "/api/3d-config":
        return route.fulfill(status=200, content_type="application/json", body=json.dumps(S["config"]))
    if path == "/api/3d-create":
        S["creates"].append(json.loads(request.post_data))
        if S["create_abort"]:
            return route.abort()
        if S["create_fail"]:
            code, msg = S["create_fail"]
            return route.fulfill(status=code, content_type="application/json", body=json.dumps({"error": msg}))
        return route.fulfill(status=200, content_type="application/json", body=json.dumps({"taskId": "task_1", "status": "queued", "reused": False}))
    if path == "/api/3d-status":
        seq = S["status_seq"]
        step = seq[min(S["statuses"], len(seq) - 1)]
        S["statuses"] += 1
        if "http" in step:
            return route.fulfill(status=step["http"], content_type="application/json", body=json.dumps({"error": step.get("error")}))
        body = {"taskId": "task_1", "error": step.get("error")} | step
        return route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
    if path == "/api/3d-asset":
        S["assets"] += 1
        return route.fulfill(status=200, content_type="model/gltf-binary", body=GLB)
    return route.fulfill(status=404, body="not found")

results = []
def check(name, cond):
    results.append(bool(cond))
    print(("PASS " if cond else "FAIL ") + name)

srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(
    type("Quiet", (http.server.SimpleHTTPRequestHandler,), {"log_message": lambda self, *a: None}), directory=HERE))
BASE = "http://127.0.0.1:%d" % srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

def open_page(b, signed_in=True, vp=(1280, 800), open_panel=True):
    ctx = b.new_context(viewport={"width": vp[0], "height": vp[1]})
    if signed_in:
        ctx.add_init_script("try{ if(!localStorage.getItem('aviqo_user')) localStorage.setItem('aviqo_user', JSON.stringify({email:'maker@example.com'})) }catch(e){}")
    pg = ctx.new_page()
    pg.route(re.compile(r"https://cdn\.jsdelivr\.net/.*"), cdn)
    pg.route(re.compile(r".*/api/.*"), api)
    pg.goto(BASE + "/3d-studio.html")
    pg.wait_for_function("document.getElementById('aiAvail').textContent.length > 0 && !document.getElementById('aiAvail').textContent.startsWith('Checking')", timeout=8000)
    if open_panel:
        pg.click("#aiFab")
    return ctx, pg

def fill_text(pg, prompt="Create a low-poly wooden chair with a red cushion", consent=True):
    pg.fill("#aiPrompt", prompt)
    if consent:
        pg.check("#aiConsent")

def add_from_preview(pg):
    pg.wait_for_selector(".ai-preview", timeout=20000)
    pg.click(".ai-preview .btn:has-text('Add to Scene')")
    pg.wait_for_function("document.getElementById('aiMsg').textContent.includes('Added')", timeout=5000)

def pending(pg):
    return pg.evaluate("localStorage.getItem('aviqo3d_pending')")

def msg(pg):
    return pg.text_content("#aiMsg") or ""

with sync_playwright() as p:
    b = p.chromium.launch()

    # 1. Gate: server says no key configured. Panel hidden, nothing callable.
    reset(config={"available": False, "reason": "no_key", "costText": 10, "costImage": 12})
    ctx, pg = open_page(b)
    check("no_key: chat input still usable for local editing", pg.is_visible("#aiPrompt") and not pg.is_visible("#aiConsentRow"))
    pg.fill("#aiPrompt", "help"); pg.press("#aiPrompt", "Enter"); pg.wait_for_timeout(150)
    check("no_key: local help answered without the AI service", "Ctrl+Z" in pg.text_content("#aiLog"))
    pg.fill("#aiPrompt", "Create a tree"); pg.press("#aiPrompt", "Enter"); pg.wait_for_timeout(150)
    check("no_key: generation refused, no create call made", len(S["creates"]) == 0)
    ctx.close()

    # 2. Signed out: panel shows, generate disabled, asks to sign in.
    reset()
    ctx, pg = open_page(b, signed_in=False)
    check("signed out: panel visible", pg.is_visible("#aiBox"))
    check("signed out: generate disabled", pg.is_disabled("#aiGenerate"))
    check("signed out: asks to sign in", "Sign in" in msg(pg))
    ctx.close()

    # 3. Gates on the button: needs prompt AND consent.
    reset()
    ctx, pg = open_page(b)
    check("text: disabled with no prompt", pg.is_disabled("#aiGenerate"))
    pg.fill("#aiPrompt", "a chair")
    check("text: enabled once text is typed (cost checked on send)", pg.is_enabled("#aiGenerate"))
    pg.check("#aiConsent")
    check("text: enabled with prompt and consent", pg.is_enabled("#aiGenerate"))
    check("text: cost line shows 10 credits", "10 credits" in pg.text_content("#aiCostText"))
    check("prompt is limited to 1024 characters", pg.get_attribute("#aiPrompt", "maxlength") == "1024")
    ctx.close()

    # 4. Happy path: create -> poll -> download -> object added.
    reset()
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    add_from_preview(pg)
    sent = S["creates"][0]
    check("create: sends email, kind text, prompt", sent["email"] == "maker@example.com" and sent["kind"] == "text" and sent["prompt"].startswith("Create a low-poly"))
    check("create: requestId is a UUID-like id", bool(re.match(r"^[0-9a-f-]{8,64}$", sent["requestId"])))
    check("create: exactly one job", len(S["creates"]) == 1)
    check("asset downloaded once", S["assets"] == 1)
    check("object list shows the AI model", "AI Create a low-poly" in pg.text_content("#objectList"))
    check("pending job cleared after success", pending(pg) is None)
    check("after success: draft cleared, send disabled", pg.is_disabled("#aiGenerate") and "Added" in msg(pg))
    ctx.close()

    # 5. Pause, then resume finishes the job.
    reset(status_seq=[{"status": "running", "progress": 30, "ready": False},
                      {"status": "running", "progress": 70, "ready": False},
                      {"status": "success", "progress": 100, "ready": True}])
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiStatus').textContent.includes('Generating')", timeout=10000)
    pg.click("#aiPause")
    check("pause: resume and discard offered", pg.is_visible("#aiResume") and pg.is_visible("#aiDiscard") and not pg.is_visible("#aiPause"))
    check("pause: job kept in storage", pending(pg) is not None)
    polls_at_pause = S["statuses"]
    pg.wait_for_timeout(3500)
    check("pause: no polling while paused", S["statuses"] == polls_at_pause)
    pg.click("#aiResume")
    add_from_preview(pg)
    check("resume: model added after resume", "AI Create a low-poly" in pg.text_content("#objectList"))
    ctx.close()

    # 6. Discard stops everything and forgets the job.
    reset(status_seq=[{"status": "running", "progress": 20, "ready": False}])
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiStatus').textContent.includes('Generating')", timeout=10000)
    pg.click("#aiPause")
    pg.click("#aiResume")
    pg.wait_for_timeout(200)
    pg.click("#aiDiscard")
    n = S["statuses"]
    pg.wait_for_timeout(4000)
    check("discard: pending job forgotten", pending(pg) is None)
    check("discard: polling stopped", S["statuses"] == n)
    check("discard: discard message shown", "Discarded" in msg(pg))
    fill_text(pg, "a second chair")
    check("discard: a new message can be sent", pg.is_enabled("#aiGenerate"))
    ctx.close()

    # 7. Provider failure during generation: clear message, no model, no pending job.
    reset(status_seq=[{"status": "failed", "progress": 100, "ready": False, "error": "Generation failed. You have not been charged."}])
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').dataset.kind === 'error'", timeout=10000)
    check("failed task: shows the provider reason", "not been charged" in msg(pg))
    check("failed task: no asset download", S["assets"] == 0)
    check("failed task: nothing pending", pending(pg) is None)
    ctx.close()

    # 8. Create refused: insufficient credits, nothing pending, can try again.
    reset(create_fail=(402, "Not enough credits for 3D generation (needs 10)."))
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').dataset.kind === 'error'", timeout=8000)
    check("402: shows not-enough-credits", "Not enough credits" in msg(pg))
    check("402: no job started", pending(pg) is None and S["statuses"] == 0)
    check("402: generate enabled to retry", pg.is_enabled("#aiGenerate"))
    ctx.close()

    # 9. Provider error on create: says not charged, retry allowed with a fresh id.
    reset(create_fail=(502, "Generation service error. You have not been charged."))
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').dataset.kind === 'error'", timeout=8000)
    check("502: says not charged", "not been charged" in msg(pg))
    S["create_fail"] = None
    pg.click("#aiLog .bubble.error .btn:has-text('Retry')")
    add_from_preview(pg)
    check("502 then retry: fresh request id after provider error", S["creates"][0]["requestId"] != S["creates"][1]["requestId"])
    ctx.close()

    # 10. Network drop on create: retry reuses the same request id, so no double job.
    reset(create_abort=True)
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').dataset.kind === 'error'", timeout=8000)
    check("network drop: friendly message", "Connection problem" in msg(pg))
    S["create_abort"] = False
    pg.click("#aiLog .bubble.error .btn:has-text('Retry')")
    add_from_preview(pg)
    check("network retry: same request id reused", len(S["creates"]) == 2 and S["creates"][0]["requestId"] == S["creates"][1]["requestId"])
    ctx.close()

    # 11. Double click cannot start two jobs.
    reset()
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.evaluate("const g=document.getElementById('aiGenerate'); g.click(); g.click();")
    add_from_preview(pg)
    check("double click: exactly one create", len(S["creates"]) == 1)
    ctx.close()

    # 12. Model finished but credits are short: server 402, job kept, resume after top-up finishes it.
    reset(status_seq=[{"http": 402, "error": "Not enough credits for 3D generation (needs 10)."}])
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').dataset.kind === 'error'", timeout=10000)
    check("402 at completion: shows not-enough-credits", "Not enough credits" in msg(pg))
    check("402 at completion: job kept for resume", pending(pg) is not None and pg.is_visible("#aiResume"))
    check("402 at completion: no model added, no download", "AI Create a low-poly" not in pg.text_content("#objectList") and S["assets"] == 0)
    S["status_seq"] = [{"status": "success", "progress": 100, "ready": True}]
    pg.click("#aiResume")
    add_from_preview(pg)
    check("after top-up: resume downloads and adds the model", "AI Create a low-poly" in pg.text_content("#objectList") and pending(pg) is None)
    ctx.close()

    # 13. Image path: picture is converted and sent as JPEG base64, not raw PNG.
    reset()
    ctx, pg = open_page(b)
    check("attach chip hidden until an image is picked", not pg.is_visible("#aiAttachChip"))
    pg.set_input_files("#aiImage", {"name": "shoe.png", "mimeType": "image/png", "buffer": PNG})
    pg.wait_for_function("document.getElementById('aiImageName').textContent.includes('is ready')", timeout=8000)
    pg.check("#aiConsent")
    check("image cost line shows 12 credits", "12 credits" in pg.text_content("#aiCostText"))
    pg.click("#aiGenerate")
    add_from_preview(pg)
    sent = S["creates"][0]
    check("image: kind image with JPEG base64", sent["kind"] == "image" and sent["imageBase64"].startswith("/9j/"))
    check("image: model name uses image label", "AI image model" in pg.text_content("#objectList"))
    ctx.close()

    # 14. Editor gate: Three.js unavailable (CDN blocked). Generation stays off, nothing is charged.
    reset()
    ctx = b.new_context(viewport={"width": 1280, "height": 800})
    ctx.add_init_script("try{ localStorage.setItem('aviqo_user', JSON.stringify({email:'maker@example.com'})) }catch(e){}")
    pg = ctx.new_page()
    pg.route(re.compile(r"https://cdn\.jsdelivr\.net/.*"), lambda r: r.abort())
    pg.route(re.compile(r".*/api/.*"), api)
    pg.goto(BASE + "/3d-studio.html")
    pg.wait_for_function("!document.getElementById('aiAvail').textContent.startsWith('Checking')", timeout=8000)
    pg.wait_for_timeout(500)
    check("no viewport: generate disabled", pg.is_disabled("#aiGenerate"))
    check("no viewport: says reload, nothing charged", "viewport" in msg(pg))
    check("no viewport: no create call", len(S["creates"]) == 0)
    ctx.close()

    # 16. Chat: suggestion chips fill the box; Enter sends; Clear empties the log; Copy on AI bubbles.
    reset()
    ctx, pg = open_page(b)
    check("chat: suggestion chips visible on empty chat", pg.is_visible("#aiChips"))
    pg.click("[data-suggest='Create a futuristic sports car.']")
    check("chat: chip fills the message box", pg.input_value("#aiPrompt") == "Create a futuristic sports car.")
    pg.check("#aiConsent")
    pg.focus("#aiPrompt")
    pg.keyboard.press("Enter")
    add_from_preview(pg)
    check("chat: Enter sends the message", len(S["creates"]) == 1 and S["creates"][0]["prompt"] == "Create a futuristic sports car.")
    check("chat: user and assistant bubbles shown", pg.locator("#aiLog .bubble.user").count() == 1 and pg.locator("#aiLog .bubble.ai").count() >= 1)
    check("chat: AI bubble has a Copy button", pg.locator("#aiLog .bubble.ai .btn:has-text('Copy')").count() >= 1)
    check("chat: suggestion chips hidden once chatting", not pg.is_visible("#aiChips"))
    pg.click("#aiClear")
    check("chat: clear leaves only the welcome and shows chips", pg.locator("#aiLog .bubble:not(.welcome)").count() == 0 and pg.locator("#aiLog .bubble.welcome").count() == 1 and pg.is_visible("#aiChips"))
    ctx.close()

    # 17. Chat: help questions are answered locally, with no generation call.
    reset()
    ctx, pg = open_page(b)
    fill_text(pg, "How do I use the 3D editor?")
    pg.click("#aiGenerate")
    check("help: answered in chat", pg.locator("#aiLog .bubble.ai:not(.welcome)").count() == 1 and "Ctrl+Z" in pg.text_content("#aiLog"))
    check("help: no generation request made", len(S["creates"]) == 0)
    ctx.close()

    # 18. Chat: empty send is refused; attached image shows a chip that can be removed.
    reset()
    ctx, pg = open_page(b)
    pg.evaluate("document.getElementById('aiGenerate').disabled = false")
    pg.click("#aiGenerate")
    check("empty send: refused with a message", "Type what you want" in msg(pg) and len(S["creates"]) == 0)
    pg.set_input_files("#aiImage", {"name": "shoe.png", "mimeType": "image/png", "buffer": PNG})
    pg.wait_for_function("document.getElementById('aiImageName').textContent.includes('is ready')", timeout=8000)
    check("attach: chip shows the file name", pg.is_visible("#aiAttachChip") and "shoe.png" in pg.text_content("#aiAttachChip"))
    pg.click("#aiDetach")
    check("attach: remove hides the chip", not pg.is_visible("#aiAttachChip"))
    ctx.close()

    # 19. Chat: a failed send keeps the message, and Retry resends it.
    reset(create_fail=(402, "Not enough credits for 3D generation (needs 10)."))
    ctx, pg = open_page(b)
    fill_text(pg, "Create a tree")
    pg.click("#aiGenerate")
    pg.wait_for_function("document.getElementById('aiMsg').dataset.kind === 'error'", timeout=8000)
    check("failed send: message kept in the box", pg.input_value("#aiPrompt") == "Create a tree")
    S["create_fail"] = None
    pg.click("#aiLog .bubble.error .btn:has-text('Retry')")
    add_from_preview(pg)
    check("retry: resent with the same text", S["creates"][-1]["prompt"] == "Create a tree")
    ctx.close()

    # 20. Floating panel: closed by default, opens from the button, minimize/expand/close, viewport stays visible.
    reset()
    ctx, pg = open_page(b, open_panel=False)
    check("panel: closed by default, button visible", (not pg.is_visible("#aiPanel")) and pg.is_visible("#aiFab"))
    pg.click("#aiFab")
    check("panel: opens from the floating button", pg.is_visible("#aiPanel") and not pg.is_visible("#aiFab"))
    check("panel: 3D viewport still visible", pg.is_visible("#viewport"))
    check("panel: typing indicator element present", pg.locator("#aiTyping").count() == 1)
    pg.click("#aiMin")
    check("panel: minimize hides the body", pg.is_visible("#aiPanel") and not pg.is_visible("#aiPanelBody"))
    pg.click("#aiMin")
    check("panel: restore shows the body", pg.is_visible("#aiPanelBody"))
    pg.click("#aiExpand")
    check("panel: expand is wider", pg.evaluate("document.getElementById('aiPanel').getBoundingClientRect().width > 500"))
    pg.click("#aiClose")
    check("panel: close hides it and shows the button", (not pg.is_visible("#aiPanel")) and pg.is_visible("#aiFab"))
    ctx.close()

    # 21. Editor commands act on the selected object; the reply reports only what was applied; undo reverts them.
    reset()
    ctx, pg = open_page(b)
    pg.fill("#aiPrompt", "Make it blue.")
    pg.click("#aiGenerate")
    check("command: no selection gives a clear message", "Select an object first" in pg.text_content("#aiLog"))
    pg.click("[data-shape='cube']")
    original = pg.input_value("[data-field=color]")
    pg.fill("#aiPrompt", "Make it blue.")
    pg.click("#aiGenerate")
    check("command blue: color field updated", pg.input_value("[data-field=color]") == "#1e63e9")
    check("command blue: reply names the change", "Changed the color" in pg.text_content("#aiLog"))
    check("command: no generation request made", len(S["creates"]) == 0)
    pg.fill("#aiPrompt", "Make it metallic.")
    pg.click("#aiGenerate")
    check("command metallic: metalness updated", abs(float(pg.input_value("[data-field=metalness]")) - 0.9) < 0.01)
    pg.fill("#aiPrompt", "Increase its size.")
    pg.click("#aiGenerate")
    check("command bigger: scale grew 25%", abs(float(pg.input_value("[data-field=scale][data-axis='0']")) - 1.25) < 0.01)
    pg.fill("#aiPrompt", "Duplicate it.")
    pg.click("#aiGenerate")
    check("command duplicate: second object added", pg.locator("#objectList li").count() == 2)
    for _ in range(4):   # duplicate, bigger, metallic, blue: four commits after the cube
        pg.click("#btnUndo")
    check("undo reverts AI commands (color back to original)", pg.input_value("[data-field=color]") == original)
    pg.fill("#aiPrompt", "Hello there.")
    pg.click("#aiGenerate")
    check("unknown text: honest reply, nothing generated", "did not understand" in pg.text_content("#aiLog") and len(S["creates"]) == 0)
    pg.fill("#aiPrompt", "Help me use the 3D editor.")
    pg.click("#aiGenerate")
    check("help command answers with editor basics", "Ctrl+Z" in pg.text_content("#aiLog"))
    ctx.close()

    # 22. Preview: nothing is added until Add to Scene; Discard leaves the scene unchanged.
    reset()
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_selector(".ai-preview", timeout=20000)
    check("preview: canvas with Add and Discard shown", pg.is_visible(".ai-preview canvas") and pg.locator(".ai-preview .btn:has-text('Discard')").count() == 1)
    check("preview: not added to the scene yet", "AI Create" not in pg.text_content("#objectList"))
    check("preview: job kept until Add or Discard", pending(pg) is not None)
    pg.click(".ai-preview .btn:has-text('Discard')")
    check("preview discard: scene unchanged, job forgotten", "AI Create" not in pg.text_content("#objectList") and pending(pg) is None)
    check("preview discard: card removed", pg.locator(".ai-preview").count() == 0)
    ctx.close()

    # 23. Preview survives Clear conversation, so a waiting model is never lost.
    reset()
    ctx, pg = open_page(b)
    fill_text(pg)
    pg.click("#aiGenerate")
    pg.wait_for_selector(".ai-preview", timeout=20000)
    pg.click("#aiClear")
    check("preview survives Clear conversation", pg.locator(".ai-preview").count() == 1)
    add_from_preview(pg)
    check("after Add from preview: object listed", "AI Create" in pg.text_content("#objectList"))
    ctx.close()

    # 15. Phone width: no horizontal overflow, panel usable.
    reset()
    ctx, pg = open_page(b, vp=(390, 844))
    pg.click("#aiClose")   # the open panel is an overlay; close it to reach the drawer toggles
    pg.click("#btnObjects")
    pg.wait_for_timeout(400)
    check("phone: no horizontal page overflow", pg.evaluate("document.documentElement.scrollWidth <= window.innerWidth"))
    pg.click("#left [data-close]")   # close the left drawer again
    pg.wait_for_timeout(300)
    pg.click("#aiFab")
    check("phone: generate button at least 44px tall", pg.evaluate("document.getElementById('aiGenerate').getBoundingClientRect().height >= 44"))
    ctx.close()

    b.close()

srv.shutdown()
print("\n%d/%d passed" % (sum(results), len(results)))

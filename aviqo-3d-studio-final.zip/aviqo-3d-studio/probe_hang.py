import functools, http.server, os, re, threading
from playwright.sync_api import sync_playwright
HERE = os.path.dirname(os.path.abspath(__file__))
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(
    type("Q", (http.server.SimpleHTTPRequestHandler,), {"log_message": lambda *a: None}), directory=HERE))
BASE = "http://127.0.0.1:%d" % srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

def run(label, cdn_handler):
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1280, "height": 800})
        pg.route(re.compile(r"https://cdn\.jsdelivr\.net/.*"), cdn_handler)
        pg.goto(BASE + "/3d-studio.html")
        pg.wait_for_timeout(1500)
        pg.click("[data-shape='cube']")
        pg.wait_for_timeout(300)
        n = pg.locator("#objectList li").count()
        disabled = pg.is_disabled("[data-mode='rotate']")
        banner = pg.text_content("#engineBanner")
        print(f"{label}: cube added {n} object(s); rotate disabled={disabled}; banner={banner[:60]!r}")
        b.close()

run("CDN fails fast (abort)", lambda r: r.abort())
run("CDN hangs (never responds)", lambda r: None)
srv.shutdown()

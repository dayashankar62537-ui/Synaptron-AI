# Phase 2 button matrix for AVIQO 3D Studio. Three.js is replaced by a no-op stub (the CDN is
# unreachable from the sandbox), so this verifies UI wiring and state, NOT real WebGL rendering.
import functools, http.server, os, re, threading
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
STUB = """
const u = () => new Proxy(function () {}, {
  get(t, k) { if (k === Symbol.toPrimitive) return () => 0; if (k === 'then' || k === Symbol.iterator) return undefined;
    if (k === 'domElement') return document.createElement('canvas'); return u(); },
  set() { return true; }, apply() { return u(); }, construct() { return u(); } });
export const BoxGeometry = u(), CylinderGeometry = u(), SphereGeometry = u(), Color = u(), DirectionalLight = u(),
  GridHelper = u(), Group = u(), HemisphereLight = u(), MathUtils = u(), Mesh = u(), MeshStandardMaterial = u(),
  Object3D = u(), PerspectiveCamera = u(), Raycaster = u(), Scene = u(), Vector2 = u(), Vector3 = u(),
  WebGLRenderer = u(), Box3 = u();
"""
ADDONS = """
const u = () => new Proxy(function () {}, {
  get(t, k) { if (k === Symbol.toPrimitive) return () => 0; if (k === 'then') return undefined; return u(); },
  set() { return true; }, apply() { return u(); }, construct() { return u(); } });
export const OrbitControls = u(), TransformControls = u();
export class GLTFLoader { parse(d, p, ok) { ok({ scene: u() }); } }
export class GLTFExporter { parse(o, done) { done(new ArrayBuffer(8)); } }
"""
results = []
def check(name, cond):
    results.append(bool(cond)); print(("PASS " if cond else "FAIL ") + name)

srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(
    type("Q", (http.server.SimpleHTTPRequestHandler,), {"log_message": lambda s, *a: None}), directory=HERE))
BASE = "http://127.0.0.1:%d" % srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

def cdn(route, request):
    if "three.module.js" in request.url: return route.fulfill(status=200, content_type="application/javascript", body=STUB)
    if "/examples/jsm/" in request.url: return route.fulfill(status=200, content_type="application/javascript", body=ADDONS)
    return route.abort()

def open_page(b, vp=(1280, 800)):
    ctx = b.new_context(viewport={"width": vp[0], "height": vp[1]}, accept_downloads=True)
    pg = ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.route(re.compile(r"https://cdn\.jsdelivr\.net/.*"), cdn)
    pg.route(re.compile(r".*/api/.*"), lambda r, q: r.fulfill(status=404, body="{}"))
    pg.goto(BASE + "/3d-studio.html")
    pg.wait_for_function("!!document.querySelector('#engineBanner') && document.getElementById('engineBanner').hidden !== undefined", timeout=8000)
    pg.wait_for_timeout(400)
    return pg, errs

def names(pg): return pg.locator("#objectList .obj-name").all_inner_texts()
def pressed(pg, mode): return pg.locator(f"[data-mode={mode}]").get_attribute("aria-pressed")

with sync_playwright() as p:
    b = p.chromium.launch()
    pg, errs = open_page(b)

    # --- Object creation: each shape adds one object of that kind
    for shape, label in [("cube", "Cube"), ("sphere", "Sphere"), ("cylinder", "Cylinder")]:
        before = len(names(pg))
        pg.click(f"[data-shape={shape}]"); pg.wait_for_timeout(80)
        new = names(pg)[before:] if len(names(pg)) > before else []
        check(f"add {label}: one object added", len(names(pg)) == before + 1)
        check(f"add {label}: named {label}", bool(new) and new[0].startswith(label))
    check("object count shows 3", "3" in pg.locator("#objectCount").inner_text())

    # --- Selection from list
    pg.locator("#objectList .obj-btn").first.click(); pg.wait_for_timeout(60)
    check("list click selects object (selInfo names it)", "Cube" in pg.locator("#selInfo").inner_text())
    check("props panel enabled for selection", pg.locator("[data-field=name]").is_enabled())

    # --- Transform modes (aria-pressed toggles, stub engine present)
    pg.click("[data-mode=rotate]"); check("Rotate mode toggles on", pressed(pg, "rotate") == "true" and pressed(pg, "translate") != "true")
    pg.click("[data-mode=scale]"); check("Scale mode toggles on", pressed(pg, "scale") == "true" and pressed(pg, "rotate") != "true")
    pg.click("[data-mode=translate]"); check("Move mode toggles on", pressed(pg, "translate") == "true")
    pg.keyboard.press("e"); check("E key -> rotate", pressed(pg, "rotate") == "true")
    pg.keyboard.press("r"); check("R key -> scale", pressed(pg, "scale") == "true")
    pg.keyboard.press("w"); check("W key -> move", pressed(pg, "translate") == "true")

    # --- Frame (F) enabled with selection, runs without error
    check("Frame enabled with selection", pg.locator("#btnFrame").is_enabled())
    pg.click("#btnFrame"); pg.wait_for_timeout(60)
    check("Frame click: no page error", not errs)

    # --- Escape clears selection
    pg.keyboard.press("Escape"); pg.wait_for_timeout(60)
    check("Escape clears selection", "Nothing selected" in pg.locator("#selInfo").inner_text())
    pg.locator("#objectList .obj-btn").first.click(); pg.wait_for_timeout(60)

    # --- Rename via Name field (commits on change)
    pg.fill("[data-field=name]", "Hero Cube"); pg.press("[data-field=name]", "Tab"); pg.wait_for_timeout(80)
    check("rename commits to list", "Hero Cube" in names(pg))

    # --- Color / roughness / metalness persist to the selected object
    pg.evaluate("""() => { const i = document.querySelector('[data-field=color]'); i.value = '#0000ff';
                   i.dispatchEvent(new Event('input', {bubbles:true})); i.dispatchEvent(new Event('change', {bubbles:true})); }""")
    pg.evaluate("""() => { const i = document.querySelector('[data-field=roughness]'); i.value = '0.2';
                   i.dispatchEvent(new Event('input', {bubbles:true})); i.dispatchEvent(new Event('change', {bubbles:true})); }""")
    pg.evaluate("""() => { const i = document.querySelector('[data-field=metalness]'); i.value = '0.8';
                   i.dispatchEvent(new Event('input', {bubbles:true})); i.dispatchEvent(new Event('change', {bubbles:true})); }""")
    pg.locator("#objectList .obj-btn").nth(1).click(); pg.locator("#objectList .obj-btn").first.click(); pg.wait_for_timeout(60)
    check("color persists after reselect", pg.input_value("[data-field=color]").lower() == "#0000ff")
    check("roughness persists after reselect", abs(float(pg.input_value("[data-field=roughness]")) - 0.2) < 0.01)
    check("metalness persists after reselect", abs(float(pg.input_value("[data-field=metalness]")) - 0.8) < 0.01)

    # --- Duplicate (button + Ctrl+D) and Delete (button + Delete key)
    n0 = len(names(pg))
    pg.click("#btnDuplicate"); pg.wait_for_timeout(60)
    check("Duplicate button adds one object", len(names(pg)) == n0 + 1)
    pg.locator("#objectList .obj-btn").first.click(); pg.keyboard.press("Control+d"); pg.wait_for_timeout(60)
    check("Ctrl+D duplicates", len(names(pg)) == n0 + 2)
    pg.locator("#objectList .obj-btn").first.click(); pg.wait_for_timeout(40)
    pg.click("#btnDelete"); pg.wait_for_timeout(60)
    check("Delete button removes selected", len(names(pg)) == n0 + 1)
    pg.locator("#objectList .obj-btn").first.click(); pg.wait_for_timeout(40)
    pg.keyboard.press("Delete"); pg.wait_for_timeout(60)
    check("Delete key removes selected", len(names(pg)) == n0)
    pg.locator("#objectList .obj-btn").first.click(); pg.wait_for_timeout(40)
    pg.click("#btnDuplicate2"); pg.wait_for_timeout(60)
    check("bottom-bar Duplicate works", len(names(pg)) == n0 + 1)
    pg.locator("#objectList .obj-btn").first.click(); pg.wait_for_timeout(40)
    pg.click("#btnDelete2"); pg.wait_for_timeout(60)
    check("bottom-bar Delete works", len(names(pg)) == n0)

    # --- Undo / Redo buttons and keys
    n1 = len(names(pg))
    pg.click("#btnUndo"); pg.wait_for_timeout(60)
    check("Undo button reverts last delete", len(names(pg)) == n1 + 1)
    pg.click("#btnRedo"); pg.wait_for_timeout(60)
    check("Redo button reapplies delete", len(names(pg)) == n1)
    pg.locator("#objectList .obj-btn").first.click(); pg.keyboard.press("Control+z"); pg.wait_for_timeout(60)
    check("Ctrl+Z undoes", len(names(pg)) == n1 + 1)
    pg.keyboard.press("Control+Shift+z"); pg.wait_for_timeout(60)
    check("Ctrl+Shift+Z redoes", len(names(pg)) == n1)

    # --- Export GLB / GLTF download with correct names
    with pg.expect_download() as d: pg.click("#btnExportGlb")
    check("Export GLB downloads aviqo-3d-studio.glb", d.value.suggested_filename == "aviqo-3d-studio.glb")
    with pg.expect_download() as d: pg.click("#btnExportGltf")
    check("Export GLTF downloads aviqo-3d-studio.gltf", d.value.suggested_filename == "aviqo-3d-studio.gltf")

    # --- Upload GLB: bad file rejected, good header accepted
    pg.set_input_files("#glbInput", files=[{"name": "bad.glb", "mimeType": "model/gltf-binary", "buffer": b"not a model at all"}])
    pg.wait_for_timeout(200)
    check("Upload GLB rejects invalid file", "not a GLB" in pg.locator("#msg").inner_text())
    good = b"glTF" + (2).to_bytes(4, "little") + (24).to_bytes(4, "little") + b"\x00" * 12
    n2 = len(names(pg))
    pg.set_input_files("#glbInput", files=[{"name": "ok.glb", "mimeType": "model/gltf-binary", "buffer": good}])
    pg.wait_for_timeout(300)
    check("Upload GLB accepts valid header and adds an object", len(names(pg)) == n2 + 1)

    # --- Delete via chat command needs confirmation; "no" keeps the object
    pg.locator("#objectList .obj-btn").first.click(); pg.wait_for_timeout(40)
    if pg.locator("#aiPanel").is_hidden():
        pg.click("#aiFab")
    pg.wait_for_function("!document.getElementById('aiPanel').hidden", timeout=3000)
    pg.fill("#aiPrompt", "delete it"); pg.keyboard.press("Enter"); pg.wait_for_timeout(120)
    check("delete command asks for confirmation", "Reply \"yes\"" in pg.locator("#aiLog").inner_text())
    n3 = len(names(pg))
    pg.fill("#aiPrompt", "no"); pg.keyboard.press("Enter"); pg.wait_for_timeout(120)
    check("answering no keeps the object", len(names(pg)) == n3 and "Cancelled" in pg.locator("#aiLog").inner_text())
    pg.fill("#aiPrompt", "delete it"); pg.keyboard.press("Enter"); pg.wait_for_timeout(120)
    pg.fill("#aiPrompt", "yes"); pg.keyboard.press("Enter"); pg.wait_for_timeout(120)
    check("answering yes deletes the selected object", len(names(pg)) == n3 - 1)

    check("no page errors across the matrix", not errs)
    pg.close()
    b.close()

print(f"\n{sum(results)}/{len(results)} passed")
